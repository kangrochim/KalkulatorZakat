package com.example.zakatapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class ZakatCalculatorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zakat_calculator)

        val hargaEmasInput = findViewById<TextInputEditText>(R.id.harga_emas_input)
        val emasInput = findViewById<TextInputEditText>(R.id.emas_grams_input)
        val hargaPerakInput = findViewById<TextInputEditText>(R.id.harga_perak_input)
        val perakInput = findViewById<TextInputEditText>(R.id.perak_grams_input)
        val usahaInput = findViewById<TextInputEditText>(R.id.usaha_input)
        val sahamInput = findViewById<TextInputEditText>(R.id.saham_input)
        val hartaLainInput = findViewById<TextInputEditText>(R.id.harta_lain_input)
        val daganganInput = findViewById<TextInputEditText>(R.id.dagangan_input)
        val uangTunaiInput = findViewById<TextInputEditText>(R.id.uang_tunai_input)
        val piutangInput = findViewById<TextInputEditText>(R.id.piutang_input)
        val hutangInput = findViewById<TextInputEditText>(R.id.hutang_input)
        val hasilText = findViewById<TextView>(R.id.hasil_text)
        val hitungButton = findViewById<Button>(R.id.hitung_button)

        hitungButton.setOnClickListener {
            try {
                val hargaEmas = hargaEmasInput.text.toString().toDoubleOrNull() ?: 0.0
                val gramEmas = emasInput.text.toString().toDoubleOrNull() ?: 0.0
                val hargaPerak = hargaPerakInput.text.toString().toDoubleOrNull() ?: 0.0
                val gramPerak = perakInput.text.toString().toDoubleOrNull() ?: 0.0

                val logamMulia = hargaEmas * gramEmas + hargaPerak * gramPerak
                val usaha = usahaInput.text.toString().toDoubleOrNull() ?: 0.0
                val saham = sahamInput.text.toString().toDoubleOrNull() ?: 0.0
                val hartaLain = hartaLainInput.text.toString().toDoubleOrNull() ?: 0.0
                val dagangan = daganganInput.text.toString().toDoubleOrNull() ?: 0.0
                val uangTunai = uangTunaiInput.text.toString().toDoubleOrNull() ?: 0.0
                val piutang = piutangInput.text.toString().toDoubleOrNull() ?: 0.0
                val hutang = hutangInput.text.toString().toDoubleOrNull() ?: 0.0

                val totalHarta = logamMulia + usaha + saham + hartaLain + dagangan + uangTunai + piutang - hutang

                val nisab = minOf(hargaEmas * 85, hargaPerak * 595)
                val zakat = if (totalHarta >= nisab) totalHarta * 0.025 else 0.0

                val status = if (zakat > 0) "Wajib Zakat" else "Tidak Wajib Zakat"
                hasilText.text = "Total Harta: Rp%,.2f\nZakat: Rp%,.2f\n$status".format(totalHarta, zakat)
            } catch (e: Exception) {
                hasilText.text = "Terjadi kesalahan input."
            }
        }
    }
}
